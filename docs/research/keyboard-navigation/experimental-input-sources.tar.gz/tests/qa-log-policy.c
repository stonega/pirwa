/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "qa-log-policy.h"

static gboolean
known_warning (const char *domain, GLogLevelFlags level, const char *message)
{
  /* Retain/count this host graphics-stack diagnostic without aborting input
   * correctness checks. GLib still prints it. Never linked into the app. */
  if (g_strcmp0 (domain, "Gdk") == 0 && (level & G_LOG_LEVEL_MASK) == G_LOG_LEVEL_WARNING && message
      && g_str_has_prefix (message,
                           "Duplicate call to gdk_frame_timings_presented() with different "
                           "values: presentation time is ")
      && g_str_has_suffix (message, "ms off from expected"))
    {
      return TRUE;
    }
  return FALSE;
}

gboolean
qa_keyboard_log_is_fatal (const char *domain, GLogLevelFlags level, const char *message,
                          gpointer warning_count)
{
  if (!known_warning (domain, level, message))
    return TRUE;
  g_atomic_int_inc ((gint *)warning_count);
  return FALSE;
}

GLogWriterOutput
qa_keyboard_log_writer (GLogLevelFlags level, const GLogField *fields, gsize count,
                        gpointer warning_count)
{
  const char *domain = NULL, *message = NULL;
  gboolean legacy = FALSE;
  for (gsize i = 0; i < count; i++)
    {
      if (g_str_equal (fields[i].key, "GLIB_OLD_LOG_API"))
        legacy = TRUE;
      /* Match only complete string fields, never arbitrary binary fields. */
      if (fields[i].length != -1)
        continue;
      if (g_str_equal (fields[i].key, "GLIB_DOMAIN"))
        domain = fields[i].value;
      else if (g_str_equal (fields[i].key, "MESSAGE"))
        message = fields[i].value;
    }
  if (!known_warning (domain, level, message))
    return g_log_writer_default (level, fields, count, NULL);
  if (!legacy)
    g_atomic_int_inc ((gint *)warning_count);
  return g_log_writer_standard_streams (level & ~G_LOG_FLAG_FATAL, fields, count, NULL);
}
