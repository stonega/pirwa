/* SPDX-License-Identifier: GPL-3.0-or-later */
#pragma once
#include <glib.h>

gboolean qa_keyboard_log_is_fatal (const char *domain, GLogLevelFlags level, const char *message,
                                   gpointer warning_count);
GLogWriterOutput qa_keyboard_log_writer (GLogLevelFlags level, const GLogField *fields, gsize count,
                                         gpointer warning_count);
