/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "qa-log-policy.h"

typedef struct
{
  const char *name, *domain;
  GLogLevelFlags level;
  const char *message;
  gboolean accepted;
  gboolean structured;
} Case;

static void
check_policy (gconstpointer data)
{
  const Case *test = data;
  if (g_test_subprocess ())
    {
      gint count = 0;
      g_log_set_always_fatal (G_LOG_FATAL_MASK | G_LOG_LEVEL_WARNING | G_LOG_LEVEL_CRITICAL);
      g_test_log_set_fatal_handler (qa_keyboard_log_is_fatal, &count);
      g_log_set_writer_func (qa_keyboard_log_writer, &count, NULL);
      if (test->structured)
        g_log_structured_standard (test->domain, test->level, __FILE__, G_STRINGIFY (__LINE__),
                                   G_STRFUNC, "%s", test->message);
      else
        g_log (test->domain, test->level, "%s", test->message);
      g_assert_cmpuint (count, ==, 1);
      return;
    }
  g_test_trap_subprocess (NULL, 0, G_TEST_SUBPROCESS_DEFAULT);
  if (test->accepted)
    g_test_trap_assert_passed ();
  else
    g_test_trap_assert_failed ();
}

int
main (int argc, char **argv)
{
  g_test_init (&argc, &argv, NULL);
  const char *known = "Duplicate call to gdk_frame_timings_presented() with different values: "
                      "presentation time is 1.234ms off from expected";
  const Case cases[]
      = { { "/qa-log/retained-diagnostic", "Gdk", G_LOG_LEVEL_WARNING, known, TRUE, FALSE },
          { "/qa-log/other-domain-fatal", "Gtk", G_LOG_LEVEL_WARNING, known, FALSE, FALSE },
          { "/qa-log/other-warning-fatal", "Gdk", G_LOG_LEVEL_WARNING, "Unexpected warning", FALSE,
            FALSE },
          { "/qa-log/critical-fatal", "Gdk", G_LOG_LEVEL_CRITICAL, known, FALSE, FALSE },
          { "/qa-log/error-fatal", "Gdk", G_LOG_LEVEL_ERROR, known, FALSE, FALSE },
          { "/qa-log/truncated-message-fatal", "Gdk", G_LOG_LEVEL_WARNING,
            "Duplicate call to gdk_frame_timings_presented() with different values: broken", FALSE,
            FALSE } };
  Case structured[G_N_ELEMENTS (cases)];
  for (guint i = 0; i < G_N_ELEMENTS (cases); i++)
    {
      g_test_add_data_func (cases[i].name, &cases[i], check_policy);
      structured[i] = cases[i];
      structured[i].name = g_strconcat (cases[i].name, "-structured", NULL);
      structured[i].structured = TRUE;
      g_test_add_data_func (structured[i].name, &structured[i], check_policy);
    }
  int result = g_test_run ();
  for (guint i = 0; i < G_N_ELEMENTS (cases); i++)
    g_free ((char *)structured[i].name);
  return result;
}
