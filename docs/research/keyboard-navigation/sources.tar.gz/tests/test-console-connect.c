/* SPDX-License-Identifier: GPL-3.0-or-later */
/* Explicit desktop QA. Synthetic frames and test:///default only. */
#include "pirwa-backend.h"
#include "pirwa-console.h"
#include "pirwa-display.h"
#include "pirwa-preferences.h"
#include <spice-client.h>

static const char *uuid = "6695eb01-f6a4-8304-79aa-97f2502e193f";
static guint attempts;
static guint socket_errors;
static guint retry_delays[32];
static guint n_delays;
static gboolean fail_connections;
static PirwaBackend *backend; /* Borrowed while the console is alive. */
static SpiceChannel *display;
static SpiceMainChannel *main_channel;
static gboolean bootstrap;
static gboolean display_enabled;
static gboolean needs_activation;
static guint pointer_positions;
static int pointer_x, pointer_y;
static SpiceInputsChannel *inputs_channel;
static guint monitor_updates;
static int requested_width, requested_height;
static GtkStack *bootstrap_stack;
static SpiceDisplayPrimary visible_frame;

gboolean __real_pirwa_display_set_primary (PirwaDisplay *self, const SpiceDisplayPrimary *primary);

gboolean
__wrap_pirwa_display_set_primary (PirwaDisplay *self, const SpiceDisplayPrimary *primary)
{
  visible_frame = *primary;
  return __real_pirwa_display_set_primary (self, primary);
}

void __real_spice_main_channel_update_display_enabled (SpiceMainChannel *channel, int id,
                                                       gboolean enabled, gboolean update);
void __real_spice_main_channel_update_display (SpiceMainChannel *channel, int id, int x, int y,
                                               int width, int height, gboolean update);

gboolean __real_spice_session_open_fd (SpiceSession *session, int fd);
PirwaReply *__real_pirwa_backend_request_finish (PirwaBackend *self, GAsyncResult *result,
                                                 GError **error);

guint
__wrap_g_timeout_add_seconds (guint interval, GSourceFunc function, gpointer data)
{
  /* Keep the production delays observable but make this deterministic fixture fast. */
  if (interval != 15)
    {
      g_assert_cmpuint (n_delays, <, G_N_ELEMENTS (retry_delays));
      retry_delays[n_delays++] = interval;
    }
  /* Window bootstrap includes cold renderer setup, especially under ASan.
   * Keep its real watchdog deadline; transport-only cases still run quickly. */
  return g_timeout_add (interval == 15 ? (bootstrap ? 15000 : 250) : 10, function, data);
}

PirwaReply *
__wrap_pirwa_backend_request_finish (PirwaBackend *self, GAsyncResult *result, GError **error)
{
  PirwaReply *reply = __real_pirwa_backend_request_finish (self, result, error);
  backend = self;
  if (!reply && error && *error)
    socket_errors++;
  return reply;
}

gboolean
__wrap_spice_channel_connect (SpiceChannel *channel)
{
  (void)channel;
  return TRUE; /* Synthetic display channels need no socket. */
}

static gboolean
send_frame (gpointer data)
{
  static guint32 pixels[16];
  g_signal_emit_by_name (data, "display-primary-create", SPICE_SURFACE_FMT_32_xRGB, 4, 4, 16, 0,
                         pixels);
  return G_SOURCE_REMOVE;
}

void
__wrap_spice_main_channel_update_display_enabled (SpiceMainChannel *channel, int id,
                                                  gboolean enabled, gboolean update)
{
  if (!bootstrap)
    {
      __real_spice_main_channel_update_display_enabled (channel, id, enabled, update);
      return;
    }
  g_assert_cmpint (id, ==, 0);
  g_assert_true (enabled);
  display_enabled = TRUE;
}

void
__wrap_spice_main_channel_update_display (SpiceMainChannel *channel, int id, int x, int y,
                                          int width, int height, gboolean update)
{
  if (!bootstrap)
    {
      __real_spice_main_channel_update_display (channel, id, x, y, width, height, update);
      return;
    }
  g_assert_cmpint (id, ==, 0);
  g_assert_true (display_enabled);
  g_assert_true (update);
  if (monitor_updates == 0)
    {
      g_assert_cmpint (width, ==, 1280);
      g_assert_cmpint (height, ==, 720);
    }
  g_assert_cmpint (width, >=, 320);
  g_assert_cmpint (height, >=, 200);
  requested_width = width;
  requested_height = height;
  if (monitor_updates++ == 0)
    {
      /* Model a disabled guest monitor: it cannot send a primary surface until
       * the client enables it and supplies a size, while the status is visible. */
      g_assert_cmpstr (gtk_stack_get_visible_child_name (bootstrap_stack), ==, "status");
      if (!needs_activation)
        send_frame (display); /* Deliver the healthy frame before any due activation timer. */
    }
}

void
__wrap_spice_inputs_channel_position (SpiceInputsChannel *channel, int x, int y, int display_id,
                                      int button_state)
{
  g_assert_true (bootstrap);
  g_assert_true (needs_activation);
  g_assert_true (channel == inputs_channel);
  g_assert_cmpstr (gtk_stack_get_visible_child_name (bootstrap_stack), ==, "status");
  g_assert_cmpuint (monitor_updates, >=, 1);
  g_assert_cmpint (display_id, ==, 0);
  g_assert_cmpint (button_state, ==, 0);
  g_assert_cmpuint (pointer_positions, <, 2);
  if (pointer_positions++ == 0)
    {
      pointer_x = x;
      pointer_y = y;
    }
  else
    {
      g_assert_cmpint (x, ==, pointer_x + 1);
      g_assert_cmpint (y, ==, pointer_y);
      g_idle_add_full (G_PRIORITY_DEFAULT_IDLE, send_frame, g_object_ref (display), g_object_unref);
    }
}

gboolean
__wrap_spice_session_open_fd (SpiceSession *session, int fd)
{
  g_assert_cmpint (fd, ==, -1);
  attempts++;
  if (bootstrap)
    {
      SpiceChannel *main = spice_channel_new (session, SPICE_CHANNEL_MAIN, 0);
      g_set_object (&main_channel, SPICE_MAIN_CHANNEL (main));
      SpiceChannel *channel = spice_channel_new (session, SPICE_CHANNEL_DISPLAY, 0);
      g_set_object (&display, channel);
      SpiceChannel *inputs = spice_channel_new (session, SPICE_CHANNEL_INPUTS, 0);
      g_set_object (&inputs_channel, SPICE_INPUTS_CHANNEL (inputs));
      g_signal_emit_by_name (inputs, "channel-event", SPICE_CHANNEL_OPENED);
      g_signal_emit_by_name (main, "main-agent-update");
      return TRUE;
    }
  if (fail_connections || attempts == 1 || attempts == 5 || attempts == 6)
    return FALSE;
  if (attempts == 2)
    return TRUE; /* Initiated, but never receives a first frame. */
  if (attempts == 3)
    return __real_spice_session_open_fd (session, fd); /* Test driver rejects the socket. */
  if (attempts == 4)
    {
      SpiceChannel *main = spice_channel_new (session, SPICE_CHANNEL_MAIN, 0);
      g_signal_emit_by_name (main, "channel-event", SPICE_CHANNEL_ERROR_CONNECT);
      g_signal_emit_by_name (main, "channel-event", SPICE_CHANNEL_CLOSED);
      return TRUE;
    }
  SpiceChannel *channel = spice_channel_new (session, SPICE_CHANNEL_DISPLAY, 0);
  g_set_object (&display, channel);
  g_idle_add_full (G_PRIORITY_DEFAULT_IDLE, send_frame, g_object_ref (channel), g_object_unref);
  return TRUE;
}

static GtkWidget *
find_type (GtkWidget *widget, GType type)
{
  if (G_TYPE_CHECK_INSTANCE_TYPE (widget, type))
    return widget;
  for (GtkWidget *child = gtk_widget_get_first_child (widget); child;
       child = gtk_widget_get_next_sibling (child))
    {
      GtkWidget *found = find_type (child, type);
      if (found)
        return found;
    }
  return NULL;
}

static void
iterate_for (guint milliseconds)
{
  gint64 deadline = g_get_monotonic_time () + milliseconds * G_TIME_SPAN_MILLISECOND;
  while (g_get_monotonic_time () < deadline)
    {
      while (g_main_context_iteration (NULL, FALSE))
        ;
      g_usleep (1000);
    }
}

static void
wait_for_display (GtkStack *stack)
{
  gint64 deadline = g_get_monotonic_time () + 5 * G_TIME_SPAN_SECOND;
  while (g_strcmp0 (gtk_stack_get_visible_child_name (stack), "display") != 0)
    {
      g_assert_cmpint (g_get_monotonic_time (), <, deadline);
      iterate_for (1);
    }
}

static void
inventory_state (int state)
{
  g_assert_nonnull (backend);
  g_autoptr (GPtrArray) machines = g_ptr_array_new_with_free_func (g_object_unref);
  g_ptr_array_add (machines, pirwa_machine_new_full (uuid, "test", "Test state", state));
  PirwaReply reply = { .machines = machines };
  g_signal_emit_by_name (backend, "inventory", &reply);
}

static void
check_monitor_bootstrap (gboolean activate, gboolean close_pending)
{
  bootstrap = TRUE;
  needs_activation = activate;
  attempts = n_delays = monitor_updates = pointer_positions = 0;
  display_enabled = FALSE;
  g_autoptr (GArray) monitors = NULL;
  g_autoptr (GSettings) preferences = pirwa_preferences_new ();
  g_autoptr (PirwaConsole) console
      = g_object_ref_sink (pirwa_console_new ("test:///default", uuid, "Disabled monitor"));
  bootstrap_stack = GTK_STACK (find_type (GTK_WIDGET (console), GTK_TYPE_STACK));
  GtkWidget *guest = find_type (GTK_WIDGET (console), PIRWA_TYPE_DISPLAY);
  g_assert_nonnull (guest);
  iterate_for (300); /* Initial mode is independent of the viewer's allocation. */
  g_assert_cmpuint (monitor_updates, ==, 1);
  GtkWindow *window = GTK_WINDOW (adw_window_new ());
  gtk_window_set_default_size (window, 800, 600);
  adw_window_set_content (ADW_WINDOW (window), GTK_WIDGET (console));
  gtk_window_present (window);
  if (close_pending)
    {
      g_assert_true (gtk_widget_get_mapped (GTK_WIDGET (console)));
      gtk_window_destroy (window);
      g_clear_object (&console);
      iterate_for (700);
      g_assert_cmpuint (pointer_positions, ==, 0);
      g_assert_cmpuint (attempts, ==, 1);
      goto cleanup;
    }
  wait_for_display (bootstrap_stack);
  g_assert_cmpuint (pointer_positions, ==, activate ? 2 : 0);
  g_assert_cmpuint (attempts, ==, 1);
  g_assert_cmpuint (n_delays, ==, 0);
  g_assert_cmpuint (monitor_updates, >=, 1);
  guint updates = monitor_updates;
  g_signal_emit_by_name (main_channel, "main-agent-update");
  iterate_for (300);
  g_assert_cmpuint (monitor_updates, ==, updates);
  gtk_window_set_default_size (window, 960, 540);
  iterate_for (400);
  g_assert_cmpuint (monitor_updates, ==, updates);
  /* The guest can choose a different aspect ratio without being resized back. */
  g_object_get (display, "monitors", &monitors, NULL);
  g_array_set_size (monitors, 1);
  g_array_index (monitors, SpiceDisplayMonitorConfig, 0)
      = (SpiceDisplayMonitorConfig){ .width = 3, .height = 2 };
  g_object_notify (G_OBJECT (display), "monitors");
  g_assert_cmpint (visible_frame.width, ==, 3);
  g_assert_cmpint (visible_frame.height, ==, 2);
  g_assert_cmpint (visible_frame.stride, ==, 16);
  g_array_index (monitors, SpiceDisplayMonitorConfig, 0).width = 10;
  g_object_notify (G_OBJECT (display), "monitors");
  g_assert_cmpint (visible_frame.width, ==, 4);
  g_assert_cmpint (visible_frame.height, ==, 4);
  g_assert_cmpuint (monitor_updates, ==, updates);
  g_assert_cmpuint (pointer_positions, ==, activate ? 2 : 0);
  g_assert_true (g_settings_set_boolean (preferences, "auto-resize-display", TRUE));
  iterate_for (400);
  g_assert_cmpuint (monitor_updates, >, updates);
  g_assert_cmpint (requested_width, ==, gtk_widget_get_width (GTK_WIDGET (bootstrap_stack)) - 12);
  g_assert_cmpint (requested_height, ==, gtk_widget_get_height (GTK_WIDGET (bootstrap_stack)) - 12);
  g_assert_true (g_settings_set_boolean (preferences, "auto-resize-display", FALSE));
  updates = monitor_updates;
  gtk_window_set_default_size (window, 800, 600);
  iterate_for (400);
  g_assert_cmpuint (monitor_updates, ==, updates);
  gtk_window_destroy (window);
  g_clear_object (&console);
cleanup:
  g_clear_object (&display);
  g_clear_object (&main_channel);
  g_clear_object (&inputs_channel);
  bootstrap_stack = NULL;
  bootstrap = FALSE;
  iterate_for (300); /* Pending resize callbacks must not access the disposed console. */
}

int
main (void)
{
  g_setenv ("GTK_A11Y", "test", TRUE);
  g_setenv ("GSETTINGS_BACKEND", "memory", TRUE);
  adw_init ();
  g_autoptr (PirwaConsole) console
      = g_object_ref_sink (pirwa_console_new ("test:///default", uuid, "Automatic connection"));
  GtkStack *stack = GTK_STACK (find_type (GTK_WIDGET (console), GTK_TYPE_STACK));
  AdwStatusPage *status = ADW_STATUS_PAGE (find_type (GTK_WIDGET (console), ADW_TYPE_STATUS_PAGE));
  g_assert_nonnull (stack);
  g_assert_nonnull (status);
  g_assert_true (GTK_IS_SPINNER (adw_status_page_get_child (status)));
  g_assert_true (gtk_spinner_get_spinning (GTK_SPINNER (adw_status_page_get_child (status))));
  g_assert_cmpuint (attempts, ==, 1); /* Construction starts the connection without input. */
  wait_for_display (stack);
  g_assert_cmpuint (attempts, ==, 7);
  g_assert_cmpuint (socket_errors, ==, 1);
  const guint expected[] = { 1, 2, 4, 8, 16, 16 };
  g_assert_cmpuint (n_delays, ==, G_N_ELEMENTS (expected));
  for (guint i = 0; i < n_delays; i++)
    g_assert_cmpuint (retry_delays[i], ==, expected[i]);
  iterate_for (300); /* A successful first frame cancels the connection watchdog. */
  g_assert_cmpuint (attempts, ==, 7);

  g_signal_emit_by_name (display, "channel-event", SPICE_CHANNEL_ERROR_IO);
  wait_for_display (stack);
  g_assert_cmpuint (attempts, ==, 8);
  g_assert_cmpuint (retry_delays[n_delays - 1], ==, 1); /* Success resets backoff. */

  g_signal_emit_by_name (display, "channel-event", SPICE_CHANNEL_CLOSED);
  inventory_state (5);
  g_assert_cmpstr (adw_status_page_get_title (status), ==, "Machine is stopped");
  g_assert_false (gtk_widget_get_visible (adw_status_page_get_child (status)));
  iterate_for (300);
  g_assert_cmpuint (attempts, ==, 8); /* Stopping cancels an already queued retry. */
  inventory_state (1);
  wait_for_display (stack);
  g_assert_cmpuint (attempts, ==, 9);

  /* Dispose with a retry pending, then again with the first-frame watchdog pending. */
  fail_connections = TRUE;
  g_signal_emit_by_name (display, "channel-event", SPICE_CHANNEL_CLOSED);
  g_clear_object (&display);
  g_clear_object (&console);
  iterate_for (300);
  g_assert_cmpuint (attempts, ==, 9);
  fail_connections = FALSE;
  attempts = 1; /* The next fixture intentionally stalls at attempt two. */
  console = g_object_ref_sink (pirwa_console_new ("test:///default", uuid, "Closing connection"));
  g_assert_cmpuint (attempts, ==, 2);
  g_clear_object (&console);
  iterate_for (300);
  g_assert_cmpuint (attempts, ==, 2);
  check_monitor_bootstrap (FALSE, FALSE);
  check_monitor_bootstrap (TRUE, FALSE);
  check_monitor_bootstrap (TRUE, TRUE);
  g_print ("PASS: automatic connection, socket/start/channel errors, first-frame timeout, "
           "bounded backoff, monitor bootstrap and activation before the first frame, recovery, "
           "lifecycle and "
           "disposal\n");
  return 0;
}
