/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "pirwa-preferences.h"

int
main (int argc, char **argv)
{
  g_setenv ("GSETTINGS_BACKEND", "memory", TRUE);
  g_test_init (&argc, &argv, NULL);
  g_autoptr (GSettings) first = pirwa_preferences_new ();
  g_assert_false (g_settings_get_boolean (first, "auto-resize-display"));
  g_assert_true (g_settings_set_boolean (first, "auto-resize-display", TRUE));
  g_autoptr (GSettings) second = pirwa_preferences_new ();
  g_assert_true (g_settings_get_boolean (second, "auto-resize-display"));
  g_assert_true (g_settings_set_boolean (second, "auto-resize-display", FALSE));
  g_assert_false (g_settings_get_boolean (first, "auto-resize-display"));
  return 0;
}
