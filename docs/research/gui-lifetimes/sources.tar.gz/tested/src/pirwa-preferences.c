/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "pirwa-preferences.h"
#include "config.h"

GSettings *
pirwa_preferences_new (void)
{
  GSettingsSchemaSource *system = g_settings_schema_source_get_default ();
  g_autoptr (GSettingsSchema) schema
      = system ? g_settings_schema_source_lookup (system, PIRWA_APPLICATION_ID, TRUE) : NULL;
  /* An older installed schema must not hide keys in a development build. */
  if (schema
      && (!g_settings_schema_has_key (schema, "use-host-proxy")
          || !g_settings_schema_has_key (schema, "selected-machines")))
    g_clear_pointer (&schema, g_settings_schema_unref);
  if (!schema)
    {
      /* Development binaries also work before the application is installed. */
      g_autoptr (GError) error = NULL;
      g_autoptr (GSettingsSchemaSource) local
          = g_settings_schema_source_new_from_directory (PIRWA_SCHEMA_DIR, system, FALSE, &error);
      if (!local)
        g_error ("Cannot load Pirwa preferences: %s", error->message);
      schema = g_settings_schema_source_lookup (local, PIRWA_APPLICATION_ID, FALSE);
    }
  if (!schema)
    g_error ("Pirwa preferences schema is missing");
  return g_settings_new_full (schema, NULL, NULL);
}

char *
pirwa_preferences_get_selected_machine (GSettings *settings, const char *uri)
{
  g_autoptr (GVariant) selections = g_settings_get_value (settings, "selected-machines");
  char *uuid = NULL;
  g_variant_lookup (selections, uri, "s", &uuid);
  return uuid;
}

gboolean
pirwa_preferences_set_selected_machine (GSettings *settings, const char *uri, const char *uuid)
{
  g_autoptr (GVariant) selections = g_settings_get_value (settings, "selected-machines");
  const char *previous = NULL;
  g_variant_lookup (selections, uri, "&s", &previous);
  if (g_strcmp0 (previous, uuid) == 0)
    return TRUE;

  GVariantBuilder builder;
  g_variant_builder_init (&builder, G_VARIANT_TYPE ("a{ss}"));
  GVariantIter iter;
  const char *connection, *selected;
  g_variant_iter_init (&iter, selections);
  while (g_variant_iter_next (&iter, "{&s&s}", &connection, &selected))
    if (!g_str_equal (connection, uri))
      g_variant_builder_add (&builder, "{ss}", connection, selected);
  g_variant_builder_add (&builder, "{ss}", uri, uuid);
  return g_settings_set_value (settings, "selected-machines", g_variant_builder_end (&builder));
}
