/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "pirwa-preferences.h"

int
main (int argc, char **argv)
{
  g_setenv ("GSETTINGS_BACKEND", "memory", TRUE);
  g_test_init (&argc, &argv, NULL);
  g_autoptr (GSettings) first = pirwa_preferences_new ();
  g_assert_true (g_settings_get_boolean (first, "use-host-proxy"));
  g_assert_true (g_settings_set_boolean (first, "use-host-proxy", FALSE));
  g_assert_false (g_settings_get_boolean (first, "auto-resize-display"));
  g_assert_true (g_settings_set_boolean (first, "auto-resize-display", TRUE));
  g_autoptr (GSettings) second = pirwa_preferences_new ();
  g_assert_false (g_settings_get_boolean (second, "use-host-proxy"));
  g_assert_true (g_settings_get_boolean (second, "auto-resize-display"));
  g_assert_true (g_settings_set_boolean (second, "auto-resize-display", FALSE));
  g_assert_false (g_settings_get_boolean (first, "auto-resize-display"));

  g_assert_null (pirwa_preferences_get_selected_machine (first, "qemu:///session"));
  g_assert_true (pirwa_preferences_set_selected_machine (first, "qemu:///session", "session-vm"));
  g_assert_true (pirwa_preferences_set_selected_machine (first, "qemu:///system", "system-vm"));
  g_autofree char *session = pirwa_preferences_get_selected_machine (second, "qemu:///session");
  g_autofree char *system = pirwa_preferences_get_selected_machine (second, "qemu:///system");
  g_assert_cmpstr (session, ==, "session-vm");
  g_assert_cmpstr (system, ==, "system-vm");
  g_assert_true (pirwa_preferences_set_selected_machine (second, "qemu:///session", "other-vm"));
  g_assert_true (pirwa_preferences_set_selected_machine (second, "qemu:///session", "other-vm"));
  g_autoptr (GSettings) reopened = pirwa_preferences_new ();
  g_autofree char *restored = pirwa_preferences_get_selected_machine (reopened, "qemu:///session");
  g_assert_cmpstr (restored, ==, "other-vm");
  g_autofree char *unchanged = pirwa_preferences_get_selected_machine (reopened, "qemu:///system");
  g_assert_cmpstr (unchanged, ==, "system-vm");
  g_autoptr (GVariant) selections = g_settings_get_value (reopened, "selected-machines");
  g_assert_cmpuint (g_variant_n_children (selections), ==, 2);
  return 0;
}
