from pathlib import Path
import subprocess,json,re
root=Path(__file__).resolve().parent
rows=[]
for cycles in [1,32]:
    with (root/f'accent-{cycles}.stdout').open('w') as out,(root/f'accent-{cycles}.stderr').open('w') as err:
        result=subprocess.run([str(root/'gtk-accent'),str(cycles)],stdout=out,stderr=err,timeout=120)
    text=(root/f'accent-{cycles}.stderr').read_text()
    css=[]
    for block in re.split(r'\n(?=(?:Direct|Indirect) leak)',text):
        if 'gtk_css_color_value_new_from_rgba' in block:
            css.append(block.splitlines()[0])
    rows.append({'cycles':cycles,'returncode':result.returncode,'summary':re.findall(r'SUMMARY:.*',text),'css':css})
(root/'accent-controls.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows))
