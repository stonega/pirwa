from pathlib import Path
import subprocess,os,re,json
root=Path(__file__).resolve().parent
binary=root.parents[2]/'build-release-review/tests/test-ui-lifetime'
results=[]
for cycles in [1,8,32]:
    with (root/f'cycles-{cycles}.stdout').open('w') as out,(root/f'cycles-{cycles}.stderr').open('w') as err:
        result=subprocess.run([str(binary),'--cycles',str(cycles)],stdout=out,stderr=err,timeout=180)
    stdout=(root/f'cycles-{cycles}.stdout').read_text()
    stderr=(root/f'cycles-{cycles}.stderr').read_text()
    objects=json.loads(stdout) if stdout.startswith('{') else None
    results.append({'cycles':cycles,'returncode':result.returncode,'objects':objects,'summary':re.findall(r'SUMMARY:.*',stderr)})
(root/'repeated-leaks.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps([{key:row[key] for key in ['cycles','returncode','summary']} for row in results]))
