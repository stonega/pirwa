from pathlib import Path
import os,subprocess,json,re,hashlib
root=Path(__file__).resolve().parent
binary=root/'pinned/sanitizer/test-ui-lifetime'
env=os.environ.copy()
env['ASAN_OPTIONS']='detect_leaks=1'
env['GSETTINGS_SCHEMA_DIR']=str(binary.parent)
rows=[]
for cycles in [1,8,32]:
    with (root/f'pinned-cycles-{cycles}.stdout').open('w') as out,(root/f'pinned-cycles-{cycles}.stderr').open('w') as err:
        result=subprocess.run([str(binary),'--cycles',str(cycles)],env=env,stdout=out,stderr=err,timeout=180)
    text=(root/f'pinned-cycles-{cycles}.stderr').read_text()
    stdout=(root/f'pinned-cycles-{cycles}.stdout').read_text()
    objects=json.loads(stdout) if stdout.startswith('{') else None
    assert objects and all(o['created']==o['finalized'] for o in objects['objects']),stdout+text[-2000:]
    rows.append({'cycles':cycles,'returncode':result.returncode,'objects':objects,'summary':re.findall(r'SUMMARY:.*',text)})
(root/'pinned-repeated-leaks.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps([{k:r[k] for k in ['cycles','returncode','summary']} for r in rows]))
