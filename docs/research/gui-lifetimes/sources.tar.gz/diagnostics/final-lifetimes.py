from pathlib import Path
import os,subprocess,json
root=Path(__file__).resolve().parent
results=[]
for variant in ['normal','sanitizer']:
    binary=root/'pinned'/variant/'test-ui-lifetime'
    env=os.environ.copy()
    env['GSETTINGS_SCHEMA_DIR']=str(binary.parent)
    env['ASAN_OPTIONS']='detect_leaks=0'
    if variant=='sanitizer':
        env['VK_DRIVER_FILES']='/usr/share/vulkan/icd.d/intel_icd.x86_64.json'
    with (root/f'final-{variant}.stdout').open('w') as out,(root/f'final-{variant}.stderr').open('w') as err:
        result=subprocess.run([str(binary),'--cycles','32'],env=env,stdout=out,stderr=err,timeout=180)
    stdout=(root/f'final-{variant}.stdout').read_text()
    results.append({'variant':variant,'returncode':result.returncode,'graphics_environment':{k:env[k] for k in ['GSK_RENDERER','VK_DRIVER_FILES'] if k in env},'objects':json.loads(stdout) if stdout.startswith('{') else None})
(root/'final-lifetimes.json').write_text(json.dumps(results,indent=2)+'\n')
assert all(r['returncode']==0 and all(o['created']==o['finalized'] for o in r['objects']['objects']) for r in results), results
print(json.dumps([{'variant':r['variant'],'cycles':r['objects']['cycles'],'finalized':sum(o['finalized'] for o in r['objects']['objects'])} for r in results]))
