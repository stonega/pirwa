from pathlib import Path
import os,subprocess,json,re
root=Path(__file__).resolve().parent
base=root.parent/'leak-assessment-20261116'
commands={'gtk':[str(base/'gtk-sanitize')], 'pirwa':[str(root.parents[2]/'build-release-review/tests/test-ui'),'--exercise']}
results=[]
for unaligned in [False,True]:
    for name,command in commands.items():
        label=f'{name}-'+('unaligned' if unaligned else 'default')
        env=os.environ.copy()
        env['GSK_RENDERER']='cairo'
        env['ASAN_OPTIONS']='detect_leaks=1:halt_on_error=1'
        env['LSAN_OPTIONS'] += ':use_unaligned='+str(int(unaligned))
        with (root/(label+'.stdout')).open('w') as out,(root/(label+'.stderr')).open('w') as err:
            completed=subprocess.run(command,env=env,stdout=out,stderr=err,timeout=60)
        stderr=(root/(label+'.stderr')).read_text()
        results.append({'case':label,'command':command,'returncode':completed.returncode,'summary':re.findall(r'SUMMARY:.*',stderr)})
(root/'controls.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results))
