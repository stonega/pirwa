#include <adwaita.h>
#include <stdio.h>
#include <fontconfig/fontconfig.h>
#include <pango/pangocairo.h>
static GMainLoop *loop;
static gint64 start;
static gboolean expired;
static void painted(GdkFrameClock *clock, gpointer data) {
  (void)clock; (void)data;
  printf("first paint: %.3f ms\n", (g_get_monotonic_time()-start)/1000.0);
  g_main_loop_quit(loop);
}
static void mapped(GtkWidget *widget, gpointer data) {
  (void)data;
  g_signal_connect(gtk_widget_get_frame_clock(widget), "after-paint", G_CALLBACK(painted), NULL);
}
static gboolean timeout_cb(gpointer data) {
  (void)data; expired=TRUE;
  printf("watchdog: %.3f ms\n", (g_get_monotonic_time()-start)/1000.0);
  g_main_loop_quit(loop); return G_SOURCE_REMOVE;
}
int main(void) {
  start=g_get_monotonic_time();
  adw_init();
  GtkWindow *window=GTK_WINDOW(adw_window_new());
  gtk_window_set_default_size(window,1040,680);
  adw_window_set_content(ADW_WINDOW(window),gtk_label_new("GTK renderer control"));
  g_signal_connect(window,"map",G_CALLBACK(mapped),NULL);
  loop=g_main_loop_new(NULL,FALSE);
  guint timer=g_timeout_add_seconds(20,timeout_cb,NULL);
  gint64 before=g_get_monotonic_time();
  gtk_window_present(window);
  printf("gtk_window_present: %.3f ms\n",(g_get_monotonic_time()-before)/1000.0);
  g_main_loop_run(loop);
  if (!expired) g_source_remove(timer);
  gtk_window_destroy(window);
  g_main_loop_unref(loop);
  while (g_main_context_iteration(NULL,FALSE));
  gdk_display_close(gdk_display_get_default());
  while (g_main_context_iteration(NULL,FALSE));
  pango_cairo_font_map_set_default(NULL);
  cairo_debug_reset_static_data();
  FcFini();
  return expired?1:0;
}
