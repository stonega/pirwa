from pathlib import Path
import datetime,difflib,gzip,hashlib,io,json,re,subprocess,tarfile

qa=Path('build/qa')
base=qa/'gui-lifetimes-20261116'
fixed=base/'settings-fix'
out=Path('docs/research/gui-lifetimes')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
raw={'desktop':{},'diagnostics':{},'headless':{}}
# Preserve attempts, including failures, independently of the accepted checks.
names=sorted({p.name for p in qa.glob('gui-*20261116*') if p.is_dir()} | {
    'settings-fix-lifetimes-20261116','settings-fix-ui-normal-20261116',
    'settings-fix-ui-sanitizer-20261116','settings-fix-heap-20261116',
    'gtk-accent-desktop-20261116','gtk-accent-literal-20261116',
    'gtk-cleanup-control-20261116','gtk-cache-cleanup-control-20261116'})
for name in names:
    directory=qa/name
    if not (directory/'report.json').exists(): continue
    logs={str(p.relative_to(directory)):p.read_text(errors='replace') for p in directory.rglob('*')
          if p.is_file() and p.suffix in ['.log','.json']}
    raw['desktop'][name]=logs
for p in sorted(base.rglob('*')):
    if not p.is_file() or 'source' in p.relative_to(base).parts: continue
    if p.suffix in ['.json','.stdout','.stderr']:
        raw['diagnostics'][str(p.relative_to(base))]=p.read_text(errors='replace')
for variant,build in [('normal','build-gui-review'),('sanitizer','build-release-review')]:
    rows=[json.loads(s) for s in (Path(build)/'meson-logs/testlog.json').read_text().splitlines() if s.strip()]
    raw['headless'][variant]=[{k:r.get(k) for k in ['name','result','returncode','duration','command','stdout','stderr']} for r in rows]
clean=read(qa/'settings-fix-clean-20261116/report.json')
raw['clean_native_build']={'report':clean,'log':(qa/'settings-fix-clean-20261116/checks.log').read_text()}
raw_bytes=json.dumps(raw,indent=2).encode()
(out/'raw-results.json.gz').write_bytes(gzip.compress(raw_bytes,mtime=0))

# A buildable frozen snapshot, plus exact pre-fix files and standalone controls.
archive_manifest={}
with tarfile.open(out/'sources.tar.gz','w:gz') as tar:
    snap=qa/'settings-fix-clean-20261116/source'
    prefixes=('src/','tests/','data/','po/','packaging/','scripts/','.github/')
    for name in sorted(clean['source_manifest']):
        if not (name.startswith(prefixes) or '/' not in name): continue
        p=snap/name
        if not p.is_file() and not p.is_symlink(): continue
        target='tested/'+name
        tar.add(p,arcname=target,recursive=False)
        archive_manifest[target]={'symlink':p.readlink().as_posix()} if p.is_symlink() else {'sha256':sha(p)}
    for p in sorted(base.glob('*.c'))+sorted(base.glob('*.py'))+sorted(fixed.glob('*.py')):
        target='diagnostics/'+str(p.relative_to(base))
        tar.add(p,arcname=target,recursive=False)
        archive_manifest[target]={'sha256':sha(p)}
    for p in sorted((base/'before-settings-fix').glob('*.c')):
        target='before-settings-fix/'+p.name
        tar.add(p,arcname=target,recursive=False)
        archive_manifest[target]={'sha256':sha(p)}
    for p in [fixed/'manifest.json',base/'pinned-manifest.json']:
        tar.add(p,arcname='diagnostics/'+str(p.relative_to(base)),recursive=False)
    b=(base/'before-settings-fix/pirwa-window.c').read_text().splitlines(True)
    a=(fixed/'source/src/pirwa-window.c').read_text().splitlines(True)
    diff=''.join(difflib.unified_diff(b,a,fromfile='before-settings-fix/pirwa-window.c',tofile='tested/src/pirwa-window.c')).encode()
    info=tarfile.TarInfo('settings-fix.patch');info.size=len(diff);tar.addfile(info,io.BytesIO(diff))
    blob=json.dumps(archive_manifest,indent=2).encode()
    info=tarfile.TarInfo('source-manifest.json');info.size=len(blob);tar.addfile(info,io.BytesIO(blob))

lifetimes=read(fixed/'final-lifetimes.json')
heaps=read(fixed/'pinned-repeated-leaks.json')
heap_summary=[]
for row in heaps:
    text=(fixed/f"pinned-cycles-{row['cycles']}.stderr").read_text()
    totals={}
    for block in text.split('\n\n'):
        m=re.match(r'(?:Direct|Indirect) leak of (\d+) byte\(s\) in (\d+) object\(s\)',block)
        if not m:continue
        kind='fontconfig' if 'libfontconfig.so' in block else 'gtk_color' if 'gtk_css_color_value_new_from_rgba' in block else 'other'
        item=totals.setdefault(kind,{'bytes':0,'allocations':0})
        item['bytes']+=int(m[1]);item['allocations']+=int(m[2])
    heap_summary.append({'cycles':row['cycles'],'process_returncode':row['returncode'],
                         'summary':row['summary'],'allocation_stacks':totals,
                         'all_observed_objects_finalized':all(o['created']==o['finalized'] for o in row['objects']['objects']),
                         'edit_refreshes':row['objects']['edit_refreshes'],
                         'edit_invalidations':row['objects']['edit_invalidations']})

pin_manifest=read(fixed/'manifest.json')
source_drift=[]
for name,expected in pin_manifest.items():
    if not name.startswith('source/'):continue
    live=Path(name.removeprefix('source/'))
    if not live.exists() or sha(live)!=expected:source_drift.append(str(live))
desktops={name:read(qa/name/'report.json') for name in [
    'settings-fix-ui-normal-20261116','settings-fix-ui-sanitizer-20261116',
    'settings-fix-lifetimes-20261116','settings-fix-heap-20261116']}
assert not source_drift,source_drift
assert all(clean['source_manifest'][name.removeprefix('source/')]['sha256']==h
           for name,h in pin_manifest.items() if name.startswith('source/'))
assert clean['passed'] and all(d['passed'] for d in desktops.values())
assert all(len(raw['headless'][v])==20 and all(t['result']=='OK' for t in raw['headless'][v]) for v in raw['headless'])
assert all(l['returncode']==0 and l['objects']['cycles']==32
           and l['objects']['edit_refreshes']==16 and l['objects']['edit_invalidations']==16
           and all(o['created']==o['finalized'] for o in l['objects']['objects']) for l in lifetimes)
assert all(h['process_returncode']==1 and h['all_observed_objects_finalized'] for h in heap_summary)
before=read(qa/'gui-edit-before-20261116/report.json')
assert not before['passed']

validation={
    'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'source_dirty':True,'application_id':'io.github.pirwa.Pirwa',
    'scope':'Private virtual GNOME, synthetic libvirt test driver; no existing guest mutations',
    'settings_fix':{'old_code_fails_deterministically':not before['passed'],
                    'pre_fix_result':before,'pre_fix_source_sha256':sha(base/'before-settings-fix/pirwa-window.c'),
                    'pre_fix_fixture_sha256':sha(base/'before-settings-fix/test-ui-lifetime.c'),
                    'pre_fix_binary_sha256':sha(base/'before-settings-fix/test-ui-lifetime'),
                    'fixed_source_sha256':sha(fixed/'source/src/pirwa-window.c'),
                    'fixed_fixture_sha256':sha(fixed/'source/tests/test-ui-lifetime.c'),
                    'connection_switch_to_same_uuid_independently_tested':False},
    'ownership':lifetimes,'pinned_input_manifest':pin_manifest,'pinned_source_drift_at_recording':source_drift,
    'desktop_matrices':{v:{'passed':desktops[n]['passed'],'cases':len(desktops[n]['cases']),
                           'graphics_environment':desktops[n]['graphics_environment']}
                        for v,n in [('normal','settings-fix-ui-normal-20261116'),('sanitizer','settings-fix-ui-sanitizer-20261116')]},
    'headless':{v:[{k:t[k] for k in ['name','result','returncode','duration']} for t in rows] for v,rows in raw['headless'].items()},
    'build_options':{v:{o['name']:o['value'] for o in read(Path(b)/'meson-info/intro-buildoptions.json')
                       if o['name'] in ['buildtype','b_sanitize','b_lundef','c_args','c_link_args','pkg_config_path','werror']}
                     for v,b in [('normal','build-gui-review'),('sanitizer','build-release-review')]},
    'execution_environment':{'loader_path':str(Path('.cache/dev-sdk/usr/lib64').resolve()),
                             'headless_ASAN_OPTIONS':'detect_leaks=1',
                             'desktop_ownership_ASAN_OPTIONS':'detect_leaks=0',
                             'heap_ASAN_OPTIONS':'detect_leaks=1',
                             'LSAN_OPTIONS':'suppressions='+str(Path('tests/lsan.supp').resolve())+':print_suppressions=1',
                             'DEBUGINFOD_URLS':'',
                             'heap_GSK_RENDERER':'cairo'},
    'heap_acceptance':'OPEN: expected nonzero processes retained; diagnostic runner success does not mean leak-free',
    'heap_results':heap_summary,
    'independent_controls':{'gtk_and_pirwa':read(base/'controls.json'),'gtk_accent':read(base/'accent-controls.json')},
    'dependency_versions':{'gtk4':'4.24.1','libadwaita':'1.10.0','pango':'1.58.2','fontconfig':'2.18.3','gnome_shell':'51.1'},
    'gtk_sources':{'installed_tag':'4.24.1','upstream_main_inspected':'278eeda31489417a425b7767ab191b3853f90d00',
                    'stable_branch_inspected':'aa434607ee6ae1076a082ec27d576f815a6d4b74','fixed_binary_tested':False,
                    'urls':['https://github.com/GNOME/gtk/blob/4.24.1/gtk/gtksettings.c#L999',
                            'https://github.com/GNOME/gtk/blob/4.24.1/gtk/gtkcsscolorvalue.c#L679',
                            'https://github.com/GNOME/gtk/blob/278eeda31489417a425b7767ab191b3853f90d00/gtk/gtksettings.c#L997']},
    'clean_native':{k:clean[k] for k in ['passed','rootless','network_during_checks','source_commit','source_dirty','image_id','rpm_requested','last_stage','headless','source_drift_since_snapshot']},
    'raw_local_directory':str(base),'clean_native_local_directory':str(qa/'settings-fix-clean-20261116'),
    'source_archive_manifest':archive_manifest,
    'artifacts':{p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in [out/'raw-results.json.gz',out/'sources.tar.gz']},
    'limitations':['Historical startup and Boxes step-4 timeout causes remain unproven',
                   'No physical input, screen-reader, guest audio/frames or real-host System authorization certification',
                   'No performance-budget acceptance from these correctness and allocation controls',
                   'No full GUI leak sign-off; no broad toolkit suppression or production renderer/CSS change',
                   'The source snapshot includes preserved concurrent preference and network UI work; final candidate review remains open']}
(out/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
print(json.dumps({'sources_bytes':(out/'sources.tar.gz').stat().st_size,'raw_compressed_bytes':(out/'raw-results.json.gz').stat().st_size,
                  'raw_uncompressed_bytes':len(raw_bytes),'desktop_attempts_retained':len(raw['desktop']),
                  'source_drift':source_drift,'heap_results':heap_summary},indent=2))
