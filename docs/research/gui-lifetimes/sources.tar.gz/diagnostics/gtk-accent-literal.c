#include <adwaita.h>
#include <stdlib.h>
static GMainLoop *loop;
static void painted(GdkFrameClock *clock, gpointer data) { (void)clock; (void)data; g_main_loop_quit(loop); }
static void mapped(GtkWidget *widget, gpointer data) { (void)data; g_signal_connect(gtk_widget_get_frame_clock(widget),"after-paint",G_CALLBACK(painted),NULL); }
static gboolean expired(gpointer data) { (void)data; g_error("GTK accent control timed out"); return G_SOURCE_REMOVE; }
int main(int argc, char **argv) {
  int cycles=argc>1?atoi(argv[1]):1;
  adw_init();
  GdkRGBA accent={.red=.2,.green=.4,.blue=.8,.alpha=1};
  g_object_set(gtk_settings_get_default(),"gtk-accent-color",&accent,NULL);
  GtkCssProvider *provider=gtk_css_provider_new();
  gtk_css_provider_load_from_string(provider,"label.probe { color: rgb(51, 102, 204); }");
  gtk_style_context_add_provider_for_display(gdk_display_get_default(),GTK_STYLE_PROVIDER(provider),GTK_STYLE_PROVIDER_PRIORITY_APPLICATION);
  g_object_unref(provider);
  loop=g_main_loop_new(NULL,FALSE);
  for(int i=0;i<cycles;i++) {
    GtkWindow *window=GTK_WINDOW(adw_window_new());
    gtk_window_set_default_size(window,640,480);
    GtkWidget *label=gtk_label_new("GTK named accent control");
    gtk_widget_add_css_class(label,"probe");
    adw_window_set_content(ADW_WINDOW(window),label);
    g_signal_connect(window,"map",G_CALLBACK(mapped),NULL);
    guint timer=g_timeout_add_seconds(20,expired,NULL);
    gtk_window_present(window);
    g_main_loop_run(loop);
    g_source_remove(timer);
    gtk_window_destroy(window);
    while(g_main_context_iteration(NULL,FALSE));
  }
  g_main_loop_unref(loop);
  g_print("completed %d minimal GTK accent cycles\n",cycles);
  return 0;
}
