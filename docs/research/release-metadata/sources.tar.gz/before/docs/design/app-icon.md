# Pirwa app icon

The icon shows a virtual computer inside a host display. A second,
offset display suggests a collection of machines. Blue keeps continuity with
Pirwa's original icon; violet distinguishes the guest and the rear display.
The pale screen and mint guest screen keep the nested shapes readable.

The design follows the [GNOME app icon guidance](https://developer.gnome.org/hig/guidelines/app-icons.html):
a 128 × 128 canvas, simple geometry, flat surfaces, a darker lower profile,
and no shadow outside the silhouette. Its bottom edge sits at y = 120.
The 16 × 16 symbolic version keeps the same layered-display metaphor.

Assets:

- [Scalable full-color icon](../../data/io.github.pirwa.Pirwa.svg)
- [Transparent 512 × 512 export](../../data/io.github.pirwa.Pirwa.png)
- [Symbolic icon](../../data/io.github.pirwa.Pirwa-symbolic.svg)
- [Size and background preview](pirwa-icon-preview.png)
- [Generated concept](pirwa-icon-concept.png)

The desktop entry uses `io.github.pirwa.Pirwa`. Meson installs the full-color
SVG into `hicolor/scalable/apps` and the symbolic SVG into `hicolor/symbolic/apps`.
Both SVGs are also embedded in the application resource bundle, so running from
the build directory uses the same artwork. The RPM includes both installed icons.
The SVGs are editable vector artwork, with no embedded bitmap, fonts, filters,
or external resources. The PNG export and preview are rendered from the SVG.

## Concept generation

The initial concept used the built-in image generation tool with transparency.
The final vector artwork simplifies that concept into flat, scalable geometry.
The exact generation prompt is in [pirwa-icon-prompt.txt](pirwa-icon-prompt.txt).

Validation covers SVG parsing, rendering at 16, 32, 64, 128 and 512 pixels,
transparent padding, and visual inspection on light and dark backgrounds.
