from pathlib import Path
import json,shutil,subprocess,tempfile
root=Path(__file__).resolve().parent
repo=Path.cwd()
command=['python3',str(repo/'scripts/check-release-metadata.py'),'--app-id','io.github.stonega.Pirwa','--version','0.1.0-dev']
rows=[]
result=subprocess.run(command,capture_output=True,text=True)
rows.append({'control':'current','returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr});assert result.returncode==0
with tempfile.TemporaryDirectory(prefix='pirwa-metadata-controls-') as tmp:
    source=Path(tmp)
    for name in ['desktop-icon','release-version','missing-screenshot']:
        fixture=source/name;shutil.copytree(repo/'data',fixture/'data');(fixture/'packaging').mkdir()
        shutil.copy2(repo/'packaging/pirwa.spec',fixture/'packaging/pirwa.spec')
        if name=='desktop-icon':
            p=fixture/'data/io.github.stonega.Pirwa.desktop';p.write_text(p.read_text().replace('Icon=io.github.stonega.Pirwa','Icon=missing'))
        elif name=='release-version':
            p=fixture/'data/io.github.stonega.Pirwa.metainfo.xml';p.write_text(p.read_text().replace('version="0.1.0-dev"','version="0.0.9"'))
        else:(fixture/'data/screenshots/collection.png').unlink()
        result=subprocess.run(command+['--source-root',str(fixture)],capture_output=True,text=True)
        rows.append({'control':name,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr});assert result.returncode!=0,name
for source_version in ['0.1.0-dev','0.1.0']:
    result=subprocess.run(['rpmspec','--define','pirwa_source_version '+source_version,'--srpm','-q','--qf','%{SOURCE}\n','packaging/pirwa.spec'],capture_output=True,text=True)
    rows.append({'control':'rpm-source-'+source_version,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
    assert result.returncode==0 and result.stdout.strip()=='pirwa-'+source_version+'.tar.xz'
for label,command in [('appstream',['appstreamcli','validate','--strict','--no-net','data/io.github.stonega.Pirwa.metainfo.xml']),
                       ('staged-tree',['appstreamcli','validate-tree','--strict','--no-net',str(root/'stage/usr/local')]),
                       ('resources',['gresource','list','build/src/pirwa'])]:
    result=subprocess.run(command,capture_output=True,text=True)
    rows.append({'control':label,'command':command,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr});assert result.returncode==0,label
(root/'controls.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps([{'control':r['control'],'returncode':r['returncode']} for r in rows],indent=2))
