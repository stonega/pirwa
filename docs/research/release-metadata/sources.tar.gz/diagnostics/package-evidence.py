from pathlib import Path
import datetime,gzip,hashlib,io,json,tarfile

qa=Path('build/qa');root=qa/'release-metadata-20261116';out=Path('docs/research/release-metadata')
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
clean=read(qa/'release-metadata-clean-20261116/report.json')
assert clean['passed']
raw={'controls':read(root/'controls.json'),'repository':read(root/'repository-verification.json'),
     'rpm_payload':read(root/'rpm-payload.json'),'captures':{},'desktop':{},'headless':{},
     'clean_native':{'report':clean,'log':(qa/'release-metadata-clean-20261116/checks.log').read_text(),
                     'staged_appstream':(qa/'release-metadata-clean-20261116/results/staged-appstream.txt').read_text()}}
for p in [root/'initial-screenshot.json',root/'screenshot.json']:
    raw['captures'][p.name]=read(p)
for p in root.glob('*screenshot.stdout'):raw['captures'][p.name]=p.read_text()
for p in root.glob('*screenshot.stderr'):raw['captures'][p.name]=p.read_text()
for name in ['release-metadata-screenshot-20261116','release-metadata-screenshot-settled-20261116',
             'release-metadata-ui-normal-20261116','release-metadata-ui-sanitizer-20261116','release-metadata-frozen-ui-normal-20261116','release-metadata-frozen-ui-sanitizer-20261116','release-metadata-frozen-schema-ui-normal-20261116','release-metadata-frozen-schema-ui-sanitizer-20261116','release-metadata-production-20261116']:
    directory=qa/name
    raw['desktop'][name]={str(p.relative_to(directory)):p.read_text(errors='replace')
                           for p in directory.rglob('*') if p.is_file() and p.suffix in ['.json','.log']}
for variant in ['normal','sanitizer']:
    log=qa/'release-metadata-clean-20261116/results'/variant/'testlog.json'
    rows=[json.loads(line) for line in log.read_text().splitlines() if line.strip()]
    assert len(rows)==21 and all(r['result']=='OK' for r in rows)
    raw['headless'][variant]=[{k:r.get(k) for k in ['name','result','returncode','duration','command','stdout','stderr']} for r in rows]
    assert all(t['result']=='OK' for t in clean['headless'][variant]) and len(clean['headless'][variant])==21
for name in ['release-metadata-frozen-schema-ui-normal-20261116','release-metadata-frozen-schema-ui-sanitizer-20261116']:
    r=read(qa/name/'report.json');assert r['passed'] and len(r['cases'])==10
production=read(qa/'release-metadata-production-20261116/profile.json');assert production['completed']
assert all(s['profile_complete'] for s in [production['warmup'],*production['launch_samples']])
assert sha(Path('data/screenshots/collection.png'))==raw['captures']['screenshot.json']['screenshot_sha256']
blob=json.dumps(raw,indent=2).encode()
(out/'raw-results.json.gz').write_bytes(gzip.compress(blob,mtime=0))

manifest={}
with tarfile.open(out/'sources.tar.gz','w:gz') as tar:
    def add(p,target):
        tar.add(p,arcname=target,recursive=False)
        manifest[target]={'symlink':p.readlink().as_posix()} if p.is_symlink() else {'sha256':sha(p)}
    snapshot=qa/'release-metadata-clean-20261116/source'
    prefixes=('src/','tests/','data/','scripts/','examples/','packaging/','po/','.github/')
    for name in sorted(clean['source_manifest']):
        if not (name.startswith(prefixes) or '/' not in name):continue
        p=snapshot/name
        if p.is_file() or p.is_symlink():add(p,'candidate/'+name)
    for p in sorted((root/'before').rglob('*')):
        if p.is_file():add(p,'before/'+str(p.relative_to(root/'before')))
    for p in sorted(root.glob('*.py'))+[root/'screenshot-node.xml',root/'initial-collection.png',root/'before-manifest.json']:
        add(p,'diagnostics/'+p.name)
    add(out/'README.md','evidence/README.md')
    add(Path('scripts/test-gnome.py'),'verified-qa/scripts/test-gnome.py')
    content=json.dumps(manifest,indent=2).encode();info=tarfile.TarInfo('source-manifest.json');info.size=len(content);tar.addfile(info,io.BytesIO(content))

source_drift=[name for name,entry in clean['source_manifest'].items() if 'sha256' in entry
              and (not Path(name).exists() or sha(Path(name))!=entry['sha256'])]
frozen=read(root/'frozen-binary-manifest.json')
for name,expected in frozen.items():assert sha(qa/'release-metadata-clean-20261116/results'/name)==expected
for variant in ['normal','sanitizer']:
    assert read(qa/f'release-metadata-frozen-schema-ui-{variant}-20261116/report.json')['schema_sha256']==frozen[variant+'/data/gschemas.compiled']
assets={}
previous=qa/'startup-menu-final-clean-20261116/source/data'
for suffix in ['.svg','-symbolic.svg','.png']:
    old=previous/('io.github.pirwa.Pirwa'+suffix)
    current=Path('data')/('io.github.stonega.Pirwa'+suffix)
    assert sha(old)==sha(current)
    assets[current.name]={'old_name':old.name,'sha256':sha(current),'content_unchanged':True}
validation={
    'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_commit':clean['source_commit'],'source_dirty':True,
    'application_id':'io.github.stonega.Pirwa','previous_application_id':'io.github.pirwa.Pirwa',
    'settings_storage_path':'/io/github/pirwa/Pirwa/','legacy_schema_installed':False,
    'repository_verification':raw['repository'],
    'publication':{'repository_visibility_changed':False,'remote_content_changed':False,'public_url_reachability_verified':False,
                   'screenshot_published':False,'tag_created':False,'release_kind':'snapshot','version':'0.1.0-dev'},
    'metadata_validation':{'strict':True,'network':False,'severity_overrides':[],
                           'pedantic_hint':'cid-contains-uppercase-letter (conventional application ID capitalization)',
                           'controls':raw['controls']},
    'asset_renames':assets,
    'screenshot':raw['captures']['screenshot.json'],
    'screenshot_review':'Final actual app-only PNG inspected; resources ready, light theme, no clipping. Initial loading-state capture retained separately.',
    'preference_compatibility':'Old and new schema IDs share the memory backend storage path; proxy, DNS, auto-resize, per-URI selection and reverse updates pass',
    'headless':{v:[{k:r[k] for k in ['name','result','returncode','duration']} for r in rows] for v,rows in raw['headless'].items()},
    'desktop':{v:{'passed':read(qa/n/'report.json')['passed'],'cases':len(read(qa/n/'report.json')['cases']),
                   'graphics_environment':read(qa/n/'report.json')['graphics_environment']}
               for v,n in [('normal','release-metadata-frozen-schema-ui-normal-20261116'),('sanitizer','release-metadata-frozen-schema-ui-sanitizer-20261116')]},
    'production_smoke':{'completed':production['completed'],'warmups':1,'measured_launches':len(production['launch_samples']),
                         'scope':'Startup correctness only; no latency percentile acceptance'},
    'clean_native':{k:clean[k] for k in ['passed','rootless','network_during_checks','image_id','last_stage','headless','source_drift_since_snapshot']},
    'source_drift_at_recording':source_drift,
    'working_tree_scope':'Later concurrent source changes are preserved and excluded from the accepted frozen candidate; this record is not a validation of those changes.',
    'rpm_payload':raw['rpm_payload'],
    'source_sha256':{n:entry['sha256'] for n,entry in clean['source_manifest'].items() if 'sha256' in entry and n.startswith(prefixes)},
    'frozen_binary_sha256':frozen,
    'verified_qa_script_sha256':sha(Path('scripts/test-gnome.py')),
    'frozen_export_initial_failure':'QA wrapper omitted the exported schema directory and reached a nonexistent /work/build/data fallback; fixed in the wrapper, with the original failed run retained',
    'source_archive_manifest':manifest,
    'artifacts':{p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in [out/'raw-results.json.gz',out/'sources.tar.gz']},
    'reference_sources':['https://www.freedesktop.org/software/appstream/docs/chap-Metadata.html',
                         'https://docs.gtk.org/gio/class.Settings.html',
                         'https://github.com/rpm-software-management/rpm/blob/master/docs/manual/autosetup.md'],
    'limitations':['Private repository and uncommitted assets; public page/image reachability and committed-candidate CI remain open',
                   'Stable release promotion, source review and remaining release acceptance are not completed',
                   'Concurrent Windows-profile work appeared after the source snapshot; the frozen candidate and its binaries are the accepted inputs',
                   'No new performance-budget claim from smoke launches or settled screenshot capture',
                   'GUI uses test accessibility and explicit Intel Vulkan for ASan/UBSan; toolkit/font-stack heap and physical-input acceptance remain open',
                   'RPM source-version queries test both development/stable archive forms, not publication of a stable package']}
(out/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
print(json.dumps({'source_drift':source_drift,'headless':{k:len(v) for k,v in raw['headless'].items()},
                  'raw_compressed_bytes':(out/'raw-results.json.gz').stat().st_size,
                  'source_archive_bytes':(out/'sources.tar.gz').stat().st_size},indent=2))
