from pathlib import Path
import os,subprocess,json,hashlib
from xml.etree import ElementTree as ET
root=Path(__file__).resolve().parent
repo=Path.cwd()
node=ET.Element('node')
for index,(name,memory,cpus) in enumerate([('Debian Stable',4096,2),('Fedora Workstation',8192,4),('Ubuntu Server',2048,2)]):
    domain=ET.SubElement(node,'domain',type='test')
    ET.SubElement(domain,'name').text=name
    ET.SubElement(domain,'uuid').text=f'{index+1:08d}-1111-4111-8111-111111111111'
    ET.SubElement(domain,'memory',unit='KiB').text=str(memory*1024)
    ET.SubElement(domain,'vcpu').text=str(cpus)
    ET.SubElement(ET.SubElement(domain,'os'),'type').text='hvm'
    ET.SubElement(domain,'{http://libvirt.org/schemas/domain/test/1.0}runstate').text='5'
    ET.SubElement(domain,'devices')
fixture=root/'screenshot-node.xml';ET.ElementTree(node).write(fixture,encoding='utf-8')
output=repo/'data/screenshots/collection.png'
command=[str(repo/'build/tests/test-ui'),'--uri','test://'+str(fixture),'--width','1088','--duration','1','--snapshot',str(output)]
with (root/'screenshot.stdout').open('w') as out,(root/'screenshot.stderr').open('w') as err:
    result=subprocess.run(command,env=dict(os.environ,GTK_A11Y='test'),stdout=out,stderr=err,timeout=60)
assert result.returncode==0,result.returncode
report={'command':command,'returncode':result.returncode,'scope':'Actual Pirwa window with three stopped synthetic test-driver machines; no real guests',
        'binary_sha256':hashlib.sha256((repo/'build/tests/test-ui').read_bytes()).hexdigest(),
        'fixture_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),'screenshot_sha256':hashlib.sha256(output.read_bytes()).hexdigest(),
        'metrics':json.loads((root/'screenshot.stdout').read_text())}
(root/'screenshot.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
