import os,subprocess,json
from pathlib import Path
root=Path(__file__).resolve().parent
results=[]
for driver in ['default','intel']:
    for variant in ['normal','sanitize']:
        env=os.environ.copy()
        env.pop('VK_DRIVER_FILES',None)
        env.pop('VK_ICD_FILENAMES',None)
        if driver=='intel':
            env['VK_DRIVER_FILES']='/usr/share/vulkan/icd.d/intel_icd.x86_64.json'
        result=subprocess.run([str(root/f'gtk-{variant}')],env=env,capture_output=True,text=True,timeout=90)
        (root/f'gtk-{driver}-{variant}.stderr').write_text(result.stderr)
        results.append({'variant':variant,'driver':driver,'returncode':result.returncode,
                        'stdout':result.stdout,'graphics_environment':{k:env[k] for k in ['VK_DRIVER_FILES','GSK_RENDERER'] if k in env}})
(root/'startup-controls.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results))
