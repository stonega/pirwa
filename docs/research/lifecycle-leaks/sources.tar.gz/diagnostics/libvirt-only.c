#include <libvirt/libvirt.h>
int main(void) { virConnectPtr c=virConnectOpen("test:///default"); if(!c) return 2; return virConnectClose(c); }
