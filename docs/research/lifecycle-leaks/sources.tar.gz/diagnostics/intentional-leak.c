#include <libvirt/libvirt.h>
#include <stdlib.h>
#include <string.h>
__attribute__((noinline)) static void application_leak(void) { void *p=malloc(17); memset(p,1,17); __asm__ volatile("" : : "r"(p) : "memory"); }
int main(void) { virConnectPtr c=virConnectOpen("test:///default"); if(!c) return 2; int result=virConnectClose(c); application_leak(); return result; }
