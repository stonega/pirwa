import os,subprocess,json,time
from pathlib import Path
root=Path(__file__).resolve().parent
results=[]
for variant in ['normal','sanitize']:
    with (root/f'gtk-{variant}.stdout').open('w') as out,(root/f'gtk-{variant}.stderr').open('w') as err:
        child=subprocess.Popen([str(root/f'gtk-{variant}')],stdout=out,stderr=err)
        if variant=='sanitize':
            time.sleep(3)
            if child.poll() is None:
                with (root/'gtk-sanitize-stack.log').open('w') as stack:
                    subprocess.run(['gdb','-q','-nx','--batch','-ex','set debuginfod enabled off',
                        '-ex','set pagination off','-ex','thread apply all bt 10','-ex','detach','-p',str(child.pid)],
                        stdout=stack,stderr=subprocess.STDOUT,timeout=30)
        code=child.wait(timeout=90)
        results.append({'variant':variant,'returncode':code,'stdout':(root/f'gtk-{variant}.stdout').read_text()})
(root/'renderer-control.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results))
