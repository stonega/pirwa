#include <libvirt/libvirt.h>
#include "pirwa-backend.h"
#include <string.h>
static GThread *thread;
static gpointer state;
static guint freed;
static gboolean complete;
GThread *__real_g_thread_new(const char *, GThreadFunc, gpointer);
GThread *__wrap_g_thread_new(const char *name, GThreadFunc func, gpointer data) {
  GThread *result = __real_g_thread_new(name, func, data);
  if (g_str_equal(name, "pirwa-backend")) thread = g_thread_ref(result);
  return result;
}
static virFreeCallback domain_free, close_free;
static void lifecycle_free(void *data) { g_print("free lifecycle\n"); domain_free(data); }
static void tray_free(void *data) { g_print("free tray\n"); domain_free(data); }
static void closing_free(void *data) { g_print("free close\n"); close_free(data); }
int __real_virConnectRegisterCloseCallback(virConnectPtr, virConnectCloseFunc, void *, virFreeCallback);
int __wrap_virConnectRegisterCloseCallback(virConnectPtr c, virConnectCloseFunc cb, void *data, virFreeCallback fn) {
  close_free=fn;
  int result=__real_virConnectRegisterCloseCallback(c,cb,data,closing_free);
  g_print("register close: %d\n",result);
  return result;
}
int __real_virConnectUnregisterCloseCallback(virConnectPtr, virConnectCloseFunc);
int __wrap_virConnectUnregisterCloseCallback(virConnectPtr c, virConnectCloseFunc cb) {
  int result=__real_virConnectUnregisterCloseCallback(c,cb);
  g_print("unregister close: %d\n",result);
  return result;
}
int __real_virConnectClose(virConnectPtr);
int __wrap_virConnectClose(virConnectPtr c) {
  int result=__real_virConnectClose(c);
  g_print("close connection: %d\n",result);
  return result;
}
int __real_virConnectDomainEventRegisterAny(virConnectPtr, virDomainPtr, int, virConnectDomainEventGenericCallback, void *, virFreeCallback);
int __wrap_virConnectDomainEventRegisterAny(virConnectPtr c, virDomainPtr d, int id, virConnectDomainEventGenericCallback cb, void *data, virFreeCallback fn) {
  state = data;
  domain_free=fn;
  int result=__real_virConnectDomainEventRegisterAny(c,d,id,cb,data,id==VIR_DOMAIN_EVENT_ID_LIFECYCLE?lifecycle_free:tray_free);
  g_print("register event %d: %d\n",id,result);
  return result;
}
void __real_g_free(gpointer);
void __wrap_g_free(gpointer ptr) {
  if (ptr && ptr == state) { state = NULL; freed++; }
  __real_g_free(ptr);
}
static gboolean expire(gpointer data) { *(gboolean *)data=TRUE; return G_SOURCE_REMOVE; }
static void done(GObject *source, GAsyncResult *result, gpointer data) {
  (void)data;
  GError *error = NULL;
  PirwaReply *reply = pirwa_backend_request_finish(PIRWA_BACKEND(source), result, &error);
  g_assert_no_error(error);
  pirwa_reply_free(reply);
  complete = TRUE;
}
int main(void) {
  PirwaBackend *backend = pirwa_backend_new("test:///default");
  PirwaRequest request = {.operation=PIRWA_REFRESH};
  pirwa_backend_request_async(backend, &request, NULL, done, NULL);
  while (!complete) g_main_context_iteration(NULL, TRUE);
  pirwa_backend_stop(backend);
  g_thread_join(thread);
  g_object_unref(backend);
  gboolean expired=FALSE;
  g_timeout_add(1000,expire,&expired);
  while (!expired) g_main_context_iteration(NULL,TRUE);
  g_print("Backend states freed after worker exit and main-loop drain: %u\n", freed);
  state = NULL;
  return freed != 1;
}
