/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "pirwa-config.h"
#include "pirwa-network.h"

static const char *original
    = "<domain type='test'><name>proxy-test</name>"
      "<uuid>88888888-8888-4888-8888-888888888888</uuid><memory>131072</memory>"
      "<vcpu>1</vcpu><os><type>hvm</type></os><devices><interface type='user'>"
      "<mac address='52:54:00:12:34:56'/><model type='virtio'/><backend type='passt'/>"
      "</interface></devices></domain>";

static void
test_runtime (void)
{
  g_autoptr (GError) error = NULL;
  g_autofree char *xml = pirwa_network_domain (original, 34567, &error);
  g_assert_no_error (error);
  g_assert_true (pirwa_config_supports (
      xml,
      "/domain/devices/interface[@type='client']/source[@address='127.0.0.1'][@port='34567']"));
  g_assert_true (
      pirwa_config_supports (xml, "/domain/devices/interface/mac[@address='52:54:00:12:34:56']"));
  g_assert_true (pirwa_config_supports (xml, "/domain/devices/interface/model[@type='virtio']"));
  g_assert_false (pirwa_config_supports (xml, "/domain/devices/interface/backend"));
  virConnectPtr connection = virConnectOpen ("test:///default");
  g_assert_nonnull (connection);
  virDomainPtr domain = virDomainDefineXML (connection, original);
  g_assert_nonnull (domain);
  g_autofree char *before = virDomainGetXMLDesc (domain, VIR_DOMAIN_XML_INACTIVE);
  virDomainPtr running = virDomainCreateXML (connection, xml, 0);
  g_assert_nonnull (running);
  g_assert_cmpint (virDomainIsPersistent (running), ==, 1);
  g_autofree char *live = virDomainGetXMLDesc (running, 0);
  g_assert_true (pirwa_config_supports (live, "/domain/devices/interface[@type='client']"));
  g_autofree char *saved = virDomainGetXMLDesc (running, VIR_DOMAIN_XML_INACTIVE);
  g_assert_cmpstr (saved, ==, before);
  g_assert_cmpint (virDomainDestroy (running), ==, 0);
  g_autofree char *after = virDomainGetXMLDesc (domain, VIR_DOMAIN_XML_INACTIVE);
  g_assert_cmpstr (after, ==, before);
  g_assert_cmpint (virDomainUndefine (domain), ==, 0);
  virDomainFree (running);
  virDomainFree (domain);
  virConnectClose (connection);
}

static void
test_reject (void)
{
  const char *unsupported[]
      = { "<domain><devices><interface type='bridge'/></devices></domain>",
          "<domain><devices><interface type='user'/><interface type='user'/></devices></domain>",
          "<domain><devices><interface type='user'><portForward "
          "proto='tcp'/></interface></devices></domain>",
          "<domain><devices/></domain>",
          "<!DOCTYPE domain><domain/>",
          "not xml" };
  for (guint i = 0; i < G_N_ELEMENTS (unsupported); i++)
    {
      g_autoptr (GError) error = NULL;
      g_assert_null (pirwa_network_domain (unsupported[i], 34567, &error));
      g_assert_nonnull (error);
    }
}

int
main (int argc, char **argv)
{
  g_test_init (&argc, &argv, NULL);
  g_test_add_func ("/network/runtime-only", test_runtime);
  g_test_add_func ("/network/unsupported", test_reject);
  return g_test_run ();
}
