/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "pirwa-preferences.h"
#include "config.h"

GSettings *
pirwa_preferences_new (void)
{
  GSettingsSchemaSource *system = g_settings_schema_source_get_default ();
  g_autoptr (GSettingsSchema) schema
      = system ? g_settings_schema_source_lookup (system, PIRWA_APPLICATION_ID, TRUE) : NULL;
  /* An older installed schema must not hide keys in a development build. */
  if (schema && !g_settings_schema_has_key (schema, "use-host-proxy"))
    g_clear_pointer (&schema, g_settings_schema_unref);
  if (!schema)
    {
      /* Development binaries also work before the application is installed. */
      g_autoptr (GError) error = NULL;
      g_autoptr (GSettingsSchemaSource) local
          = g_settings_schema_source_new_from_directory (PIRWA_SCHEMA_DIR, system, FALSE, &error);
      if (!local)
        g_error ("Cannot load Pirwa preferences: %s", error->message);
      schema = g_settings_schema_source_lookup (local, PIRWA_APPLICATION_ID, FALSE);
    }
  if (!schema)
    g_error ("Pirwa preferences schema is missing");
  return g_settings_new_full (schema, NULL, NULL);
}
