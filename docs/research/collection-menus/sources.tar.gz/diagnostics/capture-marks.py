from pathlib import Path
import os,subprocess,json,base64
root=Path(__file__).resolve().parent
pin=root/'pinned'
env=os.environ.copy()
env.update(GTK_A11Y='test',DEBUGINFOD_URLS='',GSETTINGS_BACKEND='memory',GSETTINGS_SCHEMA_DIR=str(pin),
           LD_PRELOAD=str(pin/'qa-application-profile.so'),PIRWA_LIBVIRT_URI='test://'+str(root/'fixture/node.xml'),
           PIRWA_PROFILE_OUTPUT=str(root/'marks-profile.json'),PIRWA_PROFILE_DOMAINS='100')
with (root/'startup.syscap').open('wb') as trace,(root/'marks.stderr').open('w') as err:
    env['SYSPROF_TRACE_FD']=str(trace.fileno())
    result=subprocess.run([str(pin/'pirwa')],env=env,pass_fds=[trace.fileno()],stdout=subprocess.DEVNULL,stderr=err,timeout=90)
    assert result.returncode==0,result.returncode
output=subprocess.check_output([str(root/'marks'),str(root/'startup.syscap')],text=True)
rows=[]
for line in output.splitlines():
    fields=line.split('\t')
    if len(fields)!=6:continue
    rows.append(dict(start_ns=int(fields[0]),duration_ns=int(fields[1]),pid=int(fields[2]),
                     **{k:base64.b64decode(v).decode(errors='replace') for k,v in zip(['group','name','message'],fields[3:])}))
(root/'marks.json').write_text(json.dumps(rows,indent=2)+'\n')
print('marks:',len(rows),'capture bytes:',(root/'startup.syscap').stat().st_size)
print(json.dumps(sorted(rows,key=lambda r:r['duration_ns'],reverse=True)[:15],indent=2))
