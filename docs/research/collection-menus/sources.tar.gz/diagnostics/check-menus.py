from pathlib import Path
import os,subprocess,json,hashlib
root=Path(__file__).resolve().parent
repo=Path.cwd()
rows=[]
for variant,build in [('normal',repo/'build-startup-review'),('sanitizer',repo/'build-release-review')]:
    for appearance in ['light','large-dark']:
        tag=f'quality-{variant}-{appearance}'
        env=os.environ.copy();env.update(GTK_A11Y='test',DEBUGINFOD_URLS='',ASAN_OPTIONS='detect_leaks=0',
                                        GSETTINGS_BACKEND='memory',GSETTINGS_SCHEMA_DIR=str(build/'data'))
        if variant=='sanitizer':
            env['LD_LIBRARY_PATH']=str(repo/'.cache/dev-sdk/usr/lib64')
            env['VK_DRIVER_FILES']='/usr/share/vulkan/icd.d/intel_icd.x86_64.json'
        command=[str(build/'tests/test-ui'),'--uri','test://'+str(root/'fixture/node.xml'),'--exercise']
        if appearance=='large-dark':command+=['--large-text','--dark','--width','720']
        with (root/(tag+'.stdout')).open('w') as out,(root/(tag+'.stderr')).open('w') as err:
            result=subprocess.run(command,env=env,stdout=out,stderr=err,timeout=120)
        rows.append({'variant':variant,'appearance':appearance,'returncode':result.returncode,'command':command,
                     'binary_sha256':hashlib.sha256((build/'tests/test-ui').read_bytes()).hexdigest(),
                     'schema_sha256':hashlib.sha256((build/'data/gschemas.compiled').read_bytes()).hexdigest(),
                     'metrics':json.loads((root/(tag+'.stdout')).read_text()) if result.returncode==0 else None})
        (root/'quality-menus.json').write_text(json.dumps(rows,indent=2)+'\n')
        assert result.returncode==0,tag
        print('PASS',tag,flush=True)
