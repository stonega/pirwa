from pathlib import Path
import hashlib,importlib.util,json,os,shutil,subprocess
root=Path(__file__).resolve().parent
repo=Path.cwd()
spec=importlib.util.spec_from_file_location('profile_ui',repo/'scripts/profile-ui.py')
profile=importlib.util.module_from_spec(spec);spec.loader.exec_module(profile)
pin=root/'pinned';pin.mkdir(exist_ok=True)
manifest={}
for src in ['src/pirwa','tests/qa-application-profile.so','tests/test-ui','data/gschemas.compiled']:
    dst=pin/Path(src).name
    if not dst.exists():shutil.copy2(repo/'build-startup-review'/src,dst)
    manifest[dst.name]=hashlib.sha256(dst.read_bytes()).hexdigest()
(root/'pinned-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
fixture=root/'fixture';fixture.mkdir(exist_ok=True)
uri=profile.fixture(fixture,100)
for renderer in ['default','gl']:
    output=root/renderer;output.mkdir(exist_ok=True)
    env=os.environ.copy()
    env.update(GTK_A11Y='test',DEBUGINFOD_URLS='',GSETTINGS_BACKEND='memory',GSETTINGS_SCHEMA_DIR=str(pin))
    if renderer!='default':env['GSK_RENDERER']=renderer
    for index in range(3):
        capture=output/f'{index}.json'
        command=['perf','record','--clockid','mono','-e','cpu-clock:u','-F','997','--call-graph','dwarf,16384','--output',str(output/f'{index}.perf'),
                 '--','env','LD_PRELOAD='+str(pin/'qa-application-profile.so'),
                 'PIRWA_LIBVIRT_URI='+uri,'PIRWA_PROFILE_OUTPUT='+str(capture),'PIRWA_PROFILE_DOMAINS=100',str(pin/'pirwa')]
        with (output/f'{index}.stdout').open('w') as out,(output/f'{index}.stderr').open('w') as err:
            result=subprocess.run(command,env=env,stdout=out,stderr=err,timeout=90)
        assert result.returncode==0,(command,result.returncode)
        data=json.loads(capture.read_text());assert data['profile_complete'],data
        print(renderer,index,'complete',flush=True)
