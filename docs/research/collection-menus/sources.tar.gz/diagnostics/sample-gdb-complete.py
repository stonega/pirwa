from pathlib import Path
import json,os,queue,re,subprocess,threading,time
root=Path(__file__).resolve().parent
pin=root/'pinned'

class Debugger:
    def __init__(self,env,log):
        self.p=subprocess.Popen(['gdb','--quiet','--nx','--interpreter=mi2','--args',str(pin/'pirwa')],
                                env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                                text=True,bufsize=1)
        self.q=queue.Queue();self.token=0;self.log=log;self.exited=False
        def read():
            for line in self.p.stdout:self.q.put(line.rstrip('\n'))
            self.q.put(None)
        self.reader=threading.Thread(target=read,daemon=True);self.reader.start()
    def line(self):
        l=self.q.get(timeout=20)
        if l is None:raise RuntimeError('gdb ended')
        self.log.write(l+'\n');self.log.flush()
        if l.startswith('*stopped') and 'reason="exited' in l:self.exited=True
        return l
    def command(self,cmd):
        self.token+=1;token=str(self.token)
        self.p.stdin.write(token+cmd+'\n');self.p.stdin.flush()
        while True:
            l=self.line()
            if l.startswith(token+'^'):return l
    def stop(self):
        while True:
            l=self.line()
            if l.startswith('*stopped'):return l
    def close(self):
        try:self.command('-gdb-exit')
        finally:self.p.wait(timeout=10)

all_rows=[]
for renderer in ['default','gl']:
    for round in range(3):
        tag=f'gdb-complete-{renderer}-{round}'
        env=os.environ.copy();env.update(GTK_A11Y='test',DEBUGINFOD_URLS='',GSETTINGS_BACKEND='memory',GSETTINGS_SCHEMA_DIR=str(pin))
        if renderer!='default':env['GSK_RENDERER']=renderer
        profile=root/(tag+'.json')
        rows=[]
        with (root/(tag+'.mi')).open('w') as log:
            g=Debugger(env,log)
            try:
                for option in ['pagination off','confirm off','debuginfod enabled off','mi-async on','print thread-events off']:
                    assert '^done' in g.command('-gdb-set '+option)
                for name,value in {'LD_PRELOAD':str(pin/'qa-application-profile.so'),'PIRWA_LIBVIRT_URI':'test://'+str(root/'fixture/node.xml'),
                                   'PIRWA_PROFILE_OUTPUT':str(profile),'PIRWA_PROFILE_DOMAINS':'100'}.items():
                    assert '^done' in g.command('-gdb-set environment '+name+'='+value)
                assert '^done' in g.command('-break-insert -t main')
                assert '^running' in g.command('-exec-run')
                g.stop()
                for index in range(180):
                    if g.exited:break
                    response=g.command('-exec-continue')
                    if '^running' not in response:break
                    time.sleep(.01)
                    response=g.command('-exec-interrupt --all')
                    if not g.exited:g.stop()
                    if g.exited:break
                    if profile.exists():
                        g.command('-exec-continue')
                        g.stop()
                        break
                    frame=g.command('-stack-list-frames --thread 1 0 48')
                    rows.append({'interrupt_monotonic_ns':time.monotonic_ns(),'frames':frame,
                                 'functions':re.findall(r'func="([^"\n]*)"',frame)})
                if not g.exited:
                    g.command('-exec-continue')
                    g.stop()
                assert g.exited,tag
            finally:g.close()
        all_rows.append({'renderer':renderer,'round':round,'samples':rows,'profile':json.loads(profile.read_text())})
        (root/'gdb-complete-samples.json').write_text(json.dumps(all_rows,indent=2)+'\n')
        print(tag,len(rows),'samples',flush=True)
