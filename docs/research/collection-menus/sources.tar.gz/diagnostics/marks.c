#include <sysprof-capture.h>
#include <glib.h>
#include <stdio.h>
int main(int argc,char **argv) {
  if(argc!=2)return 2;
  SysprofCaptureReader *reader=sysprof_capture_reader_new(argv[1]);
  if(!reader)return 3;
  SysprofCaptureFrameType type;
  while(sysprof_capture_reader_peek_type(reader,&type)) {
    if(type==SYSPROF_CAPTURE_FRAME_MARK) {
      const SysprofCaptureMark *m=sysprof_capture_reader_read_mark(reader);
      if(!m)break;
      g_autofree char *group=g_base64_encode((const guchar*)m->group,strlen(m->group));
      g_autofree char *name=g_base64_encode((const guchar*)m->name,strlen(m->name));
      g_autofree char *message=g_base64_encode((const guchar*)m->message,strlen(m->message));
      printf("%lld\t%lld\t%d\t%s\t%s\t%s\n",(long long)m->frame.time,(long long)m->duration,m->frame.pid,group,name,message);
    } else if(!sysprof_capture_reader_skip(reader))break;
  }
  sysprof_capture_reader_unref(reader);
  return 0;
}
