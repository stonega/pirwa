from pathlib import Path
import hashlib,json,shutil,subprocess,os
root=Path(__file__).resolve().parent
repo=Path.cwd()
manifest={}
for name in ['src/pirwa','tests/qa-application-profile.so','tests/test-ui','data/gschemas.compiled']:
    dst=root/'after-build'/name;dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(repo/'build-startup-review'/name,dst)
    manifest[name]=hashlib.sha256(dst.read_bytes()).hexdigest()
(root/'after-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name in ['src/pirwa-window.c','tests/test-ui.c']:
    dst=root/'after-source'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/name,dst)
env=os.environ.copy();env.update(GTK_A11Y='test',DEBUGINFOD_URLS='')
for tag,args in [('after-100',['--domains','100','--idle-seconds','60']),
                 ('after-1000',['--domains','1000','--idle-seconds','0','--scroll-seconds','5']),
                 ('after-application',['--application','--domains','100','--idle-seconds','0'])]:
    command=['python3',str(repo/'scripts/profile-ui.py'),'--build',str(root/'after-build'),'--launches','30',
             '--presentation','--display-kind','virtual','--output',str(root/(tag+'.json')),*args]
    completed=subprocess.run(command,env=env,timeout=250)
    assert completed.returncode==0,tag
