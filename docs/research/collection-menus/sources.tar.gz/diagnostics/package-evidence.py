from pathlib import Path
import datetime,difflib,gzip,hashlib,io,json,math,subprocess,tarfile

qa=Path('build/qa');root=qa/'startup-trace-20261116'
out=Path('docs/research/collection-menus')
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p95=lambda a:sorted(a)[math.ceil(.95*len(a))-1]
clean=read(qa/'startup-menu-final-clean-20261116/report.json')
assert clean['passed']
paired=read(root/'paired-summary.json')
assert len(paired)==12
quality=read(root/'quality-menus.json')
assert len(quality)==4 and all(r['returncode']==0 for r in quality)
for name in ['startup-menu-ui-normal-synced-20261116','startup-menu-ui-sanitizer-synced-20261116']:
    report=read(qa/name/'report.json');assert report['passed'] and len(report['cases'])==10
assert sha(root/'after-build/src/pirwa')==sha(Path('build-startup-review/src/pirwa'))
assert sha(root/'after-source/src/pirwa-window.c')==sha(Path('src/pirwa-window.c'))
assert clean['source_manifest']['src/pirwa-window.c']['sha256']==sha(Path('src/pirwa-window.c'))
assert clean['source_manifest']['tests/test-ui.c']['sha256']==sha(Path('tests/test-ui.c'))

raw={'profiles':{},'desktop':{},'debugger':{},'diagnostics':{},'headless':{}}
for p in sorted(root.glob('*.json')):raw['profiles'][p.name]=read(p)
for p in sorted(root.glob('*.mi')):raw['debugger'][p.name]=p.read_text(errors='replace')
for p in sorted(root.glob('*.stderr'))+sorted(root.glob('*.stdout')):
    raw['diagnostics'][p.name]=p.read_text(errors='replace')
for p in sorted((root/'default').glob('*.stderr')):
    raw['diagnostics'][str(p.relative_to(root))]=p.read_text(errors='replace')
names=['startup-trace-baseline-20261116','startup-menu-before-20261116','startup-menu-scroll-before-20261116',
       'startup-cpu-traces-20261116','startup-gtk-marks-20261116','startup-sysprof-agent-20261116',
       'startup-gdb-samples-20261116','startup-gdb-complete-20261116','startup-menu-after-20261116',
       'startup-menu-paired-20261116','startup-menu-ui-normal-20261116','startup-menu-ui-sanitizer-20261116',
       'startup-menu-ui-normal-synced-20261116','startup-menu-ui-sanitizer-synced-20261116','startup-menu-100-domains-20261116']
for name in names:
    directory=qa/name
    raw['desktop'][name]={str(p.relative_to(directory)):p.read_text(errors='replace')
                           for p in directory.rglob('*') if p.is_file() and p.suffix in ['.json','.log']}
for variant,build in [('normal','build-startup-review'),('sanitizer','build-release-review')]:
    rows=[json.loads(s) for s in (Path(build)/'meson-logs/testlog.json').read_text().splitlines() if s.strip()]
    raw['headless'][variant]=[{k:r.get(k) for k in ['name','result','returncode','duration','command','stdout','stderr']} for r in rows]
    assert len(rows)==20 and all(r['result']=='OK' for r in rows)
for name in ['startup-menu-clean-20261116','startup-menu-final-clean-20261116']:
    raw[name]={'report':read(qa/name/'report.json'),'log':(qa/name/'checks.log').read_text()}
raw_bytes=json.dumps(raw,indent=2).encode()
(out/'raw-results.json.gz').write_bytes(gzip.compress(raw_bytes,mtime=0))

archive_manifest={}
with tarfile.open(out/'sources.tar.gz','w:gz') as tar:
    def add(p,target):
        tar.add(p,arcname=target,recursive=False)
        archive_manifest[target]={'symlink':p.readlink().as_posix()} if p.is_symlink() else {'sha256':sha(p)}
    snapshot=qa/'startup-menu-final-clean-20261116/source'
    for name in sorted(clean['source_manifest']):
        if not (name.startswith(('src/','tests/','data/','po/','scripts/','packaging/','.github/')) or '/' not in name):continue
        p=snapshot/name
        if p.is_file() or p.is_symlink():add(p,'verified/'+name)
    for name in ['src/pirwa-window.c','tests/test-ui.c']:
        add(root/'source'/name,'before/'+name)
        add(root/'after-source'/name,'measured-after/'+name)
        diff=''.join(difflib.unified_diff((root/'source'/name).read_text().splitlines(True),
                                         (root/'after-source'/name).read_text().splitlines(True),
                                         fromfile='before/'+name,tofile='measured-after/'+name)).encode()
        info=tarfile.TarInfo('patches/'+Path(name).name+'.patch');info.size=len(diff);tar.addfile(info,io.BytesIO(diff))
    for name in ['docs/research/collection-menus/README.md','docs/design/architecture.md','docs/design/performance.md','docs/release/v0.1.0-readiness.md']:
        add(Path(name),'documentation/'+name)
    for p in sorted(root.glob('*.py'))+sorted(root.glob('*.c')):
        add(p,'diagnostics/'+p.name)
    for name in ['source-manifest.json','pinned-manifest.json','after-manifest.json']:
        add(root/name,'diagnostics/'+name)
    blob=json.dumps(archive_manifest,indent=2).encode();info=tarfile.TarInfo('source-manifest.json');info.size=len(blob);tar.addfile(info,io.BytesIO(blob))

summary={}
for variant in ['before','after']:
    reports=[read(root/r['profile']) for r in paired if r['mode']=='application' and r['variant']==variant]
    samples=[s for r in reports for s in r['launch_samples']]
    assert len(samples)==30 and all(r['completed'] for r in reports)
    summary[variant]={'application_launches':len(samples),
                      'launch_after_paint_p95_ms':p95([s['launch_to_after_paint_ms'] for s in samples]),
                      'launch_first_presentation_p95_ms':p95([s['launch_to_first_presentation_ms'] for s in samples]),
                      'scroll_trials':[r for r in paired if r['mode']=='scroll' and r['variant']==variant]}
source_manifest=read(root/'source-manifest.json')
changed=[p for p,h in source_manifest.items() if sha(Path(p))!=h]
assert changed==['src/pirwa-window.c','tests/test-ui.c'],changed
before100=read(qa/'startup-menu-before-20261116/profile.json')
after100=read(root/'after-100.json')
assert before100['completed'] and after100['completed']
validation={
    'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_dirty':True,
    'scope':'Frozen before/after release binaries, private 60 Hz virtual GNOME, synthetic libvirt only',
    'production_changed_files':['src/pirwa-window.c'],
    'qa_changed_files':['tests/test-ui.c'],
    'source_files_changed_since_baseline':changed,
    'baseline_source_sha256':source_manifest,
    'performance_after_source_sha256':{n:sha(root/'after-source'/n) for n in ['src/pirwa-window.c','tests/test-ui.c']},
    'verified_source_sha256':{n:sha(Path(n)) for n in ['src/pirwa-window.c','tests/test-ui.c']},
    'provenance_note':'Measured-after test-ui predates the test-only unbind-signal synchronization fix. Production code is identical; both exact test sources are archived. No performance rerun was attributed to the changed QA binary.',
    'before_binary_manifest':read(root/'pinned-manifest.json'),
    'after_binary_manifest':read(root/'after-manifest.json'),
    'build_options':{v:{o['name']:o['value'] for o in read(Path(b)/'meson-info/intro-buildoptions.json')
                       if o['name'] in ['buildtype','b_ndebug','b_sanitize','b_lundef','c_args','c_link_args','pkg_config_path']}
                     for v,b in [('release','build-startup-review'),('sanitizer','build-release-review')]},
    'paired_order':['before','after','after','before','before','after'],
    'paired_summary':summary,
    'standalone_production':{'before':read(qa/'startup-trace-baseline-20261116/profile.json')['launch_presentation_summary_ms'],
                             'after':read(root/'after-application.json')['launch_presentation_summary_ms']},
    'idle':{v:{k:r['idle'][k] for k in ['pss_kib','sample_cpu_percent','sample_frames','sample_wall_ms','renderer']}
            for v,r in [('before',before100),('after',after100)]},
    'desktop':{name:{'passed':read(qa/name/'report.json')['passed'],'cases':len(read(qa/name/'report.json')['cases'])}
               for name in ['startup-menu-ui-normal-synced-20261116','startup-menu-ui-sanitizer-synced-20261116']},
    'multi_machine_action_checks':quality,
    'headless':{v:[{k:r[k] for k in ['name','result','returncode','duration']} for r in rows] for v,rows in raw['headless'].items()},
    'clean_native':{**{k:clean[k] for k in ['passed','rootless','network_during_checks','image_id','last_stage','headless','source_drift_since_snapshot']},
                    'source_drift_at_artifact_recording':[n for n,m in clean['source_manifest'].items()
                       if 'sha256' in m and (not Path(n).exists() or sha(Path(n))!=m['sha256'])]},
    'debugger_completed_launches':len(read(root/'gdb-complete-samples.json')),
    'diagnostic_failures_retained':{'perf_record':'permission denied', 'legacy_trace_fd_bytes':(root/'startup.syscap').stat().st_size,
                                     'sysprof_agent':'org.gnome.sysprof3.profile is not registered',
                                     'partial_debugger_run':'sample limit reached during teardown',
                                     'initial_sanitizer_menu_case':'premature assertion before factory unbind; corrected using the actual unbind signal'},
    'reference_sources':['https://docs.gtk.org/gtk4/method.MenuButton.set_create_popup_func.html',
                         'https://github.com/GNOME/gtk/blob/4.24.1/gdk/gdkprofiler.c',
                         'https://github.com/GNOME/sysprof/blob/51.0/src/libsysprof-capture/sysprof-collector.c'],
    'source_archive_manifest':archive_manifest,
    'artifacts':{p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in [out/'raw-results.json.gz',out/'sources.tar.gz']},
    'limitations':['Warm-start 500 ms budget still missed; standalone production comparison showed a smaller difference',
                   'Virtual presentation interval still exceeds 16.7 ms; no physical or cold-cache acceptance',
                   'One 60-second idle trial per executable; no paired memory or broad renderer sign-off',
                   'Debugger interruptions are not CPU percentages or latency percentiles; backend-stall tracing remains open',
                   'No change to renderer policy, toolkit leak suppressions, host permissions or VM definitions',
                   'Uncommitted development tree; final release identity, metadata, source review and remaining acceptance stay open']}
(out/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
print(json.dumps({'summary':summary,'raw_bytes':len(raw_bytes),'raw_compressed_bytes':(out/'raw-results.json.gz').stat().st_size,
                  'source_bytes':(out/'sources.tar.gz').stat().st_size,'desktop_attempts':len(raw['desktop'])},indent=2))
