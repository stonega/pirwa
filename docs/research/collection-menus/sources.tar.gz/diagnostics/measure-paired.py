from pathlib import Path
import os,subprocess,json
root=Path(__file__).resolve().parent
repo=Path.cwd()
env=os.environ.copy();env.update(GTK_A11Y='test',DEBUGINFOD_URLS='')
results=[]
for mode in ['application','scroll']:
    for index,variant in enumerate(['before','after','after','before','before','after']):
        output=root/f'paired-{mode}-{index}-{variant}.json'
        options=['--application','--domains','100','--launches','10'] if mode=='application' else ['--domains','1000','--launches','1','--scroll-seconds','5']
        command=['python3',str(repo/'scripts/profile-ui.py'),'--build',str(root/(variant+'-build')),
                 '--idle-seconds','0','--presentation','--display-kind','virtual','--output',str(output),*options]
        completed=subprocess.run(command,env=env,timeout=150)
        assert completed.returncode==0,(mode,index,variant)
        report=json.loads(output.read_text());assert report['completed']
        results.append({'mode':mode,'index':index,'variant':variant,'profile':str(output.relative_to(root)),
                        'presentation':report['launch_presentation_summary_ms'],
                        'scroll':{k:report['scroll'][k] for k in ['paint_wall_p95_ms','paint_thread_cpu_p95_ms','compositor']} if 'scroll' in report else None})
        (root/'paired-summary.json').write_text(json.dumps(results,indent=2)+'\n')
